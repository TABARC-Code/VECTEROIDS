# VECTEROIDS

Vector arcade shooter. Static build. Upload and go.

No frameworks.
No build step.
No servers.

## Controls
- Arrows or WASD: rotate / thrust
- Space: fire
- H or Shift: hyperspace
- P or Esc: pause

## Notes
This is a cabinet-style project.
Local counters, fake attract habits, real regret.

Author: TABARC-Code

<p align="center"> <img src=".branding/tabarc-icon.svg" width="180" alt="TABARC-Code Icon"> </p>
